"""
Test script to verify Keynote presentation with screenshots works.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.utils import load_config, setup_logging
from src.agent.agent import AutomationAgent

def main():
    print("\n" + "=" * 80)
    print("Testing Keynote Presentation with Screenshots Fix")
    print("=" * 80 + "\n")

    # Load config
    config = load_config()
    setup_logging(config)

    # Initialize agent
    agent = AutomationAgent(config)

    # Test request - same as what failed before
    request = "take a screenshot of the chorus page of the night we met and create a slide deck with just that and email it to spamstuff062@gmail.com"

    print(f"Request: {request}\n")
    print("Running agent...\n")

    # Run agent
    result = agent.run(request)

    # Display result
    print("\n" + "=" * 80)
    print("RESULT")
    print("=" * 80)

    if result.get("error"):
        print(f"❌ Error: {result.get('message', 'Unknown error')}")
    else:
        print(f"✅ Success!")
        print(f"Status: {result['status']}")
        print(f"\nSteps executed: {result['steps_executed']}")

        if result.get('results'):
            print("\nStep Results:")
            for step_id, step_result in result['results'].items():
                status = "✓" if not step_result.get('error') else "✗"
                print(f"  {status} Step {step_id}: {step_result}")

    print("\n" + "=" * 80)

if __name__ == "__main__":
    main()
