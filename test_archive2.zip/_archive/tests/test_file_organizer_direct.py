#!/usr/bin/env python3
"""
Direct test of the FileOrganizer class with LLM-driven categorization.

Tests: "Organize all my music notes to a single folder called music stuff"
Expected: Move music-related PDFs but exclude WebAgents-Oct30th.pdf
"""

import logging
import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.automation.file_organizer import FileOrganizer
import yaml

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def test_file_organizer_direct():
    """Direct test of FileOrganizer."""

    logger.info("=" * 80)
    logger.info("Testing File Organizer (Direct)")
    logger.info("=" * 80)

    # Load configuration
    with open('config.yaml', 'r') as f:
        config = yaml.safe_load(f)

    # Create file organizer
    organizer = FileOrganizer(config)

    # Search engine not needed for basic file name categorization
    search_engine = None
    logger.info("Running with file name-based categorization only")

    # Test parameters
    category = "music notes"
    target_folder = "music stuff"
    source_directory = config.get('document_directory', './test_data')

    logger.info(f"\nCategory: '{category}'")
    logger.info(f"Target Folder: '{target_folder}'")
    logger.info(f"Source Directory: {source_directory}")
    logger.info("\n" + "=" * 80)

    # List files before
    logger.info("\nFiles in source directory:")
    for root, dirs, files in os.walk(source_directory):
        for filename in files:
            if not filename.startswith('.'):
                file_path = os.path.join(root, filename)
                size = os.path.getsize(file_path)
                logger.info(f"  - {filename} ({size} bytes)")

    logger.info("\n" + "=" * 80)

    # Execute organization
    logger.info("\nExecuting file organization...")
    result = organizer.organize_files(
        category=category,
        target_folder=target_folder,
        source_directory=source_directory,
        search_engine=search_engine,
        move=False  # Use copy for testing to preserve originals
    )

    logger.info("\n" + "=" * 80)
    logger.info("RESULT")
    logger.info("=" * 80)

    logger.info(f"Success: {result.get('success')}")
    logger.info(f"Files moved/copied: {len(result.get('files_moved', []))}")
    logger.info(f"Files skipped: {len(result.get('files_skipped', []))}")
    logger.info(f"Target path: {result.get('target_path')}")
    logger.info(f"Total evaluated: {result.get('total_evaluated')}")

    # Print moved files
    if result.get('files_moved'):
        logger.info("\nFiles MOVED/COPIED:")
        for filename in result['files_moved']:
            reason = result['reasoning'].get(filename, 'No reason provided')
            logger.info(f"  ✓ {filename}")
            logger.info(f"    → {reason}")

    # Print skipped files
    if result.get('files_skipped'):
        logger.info("\nFiles SKIPPED:")
        for filename in result['files_skipped']:
            reason = result['reasoning'].get(filename, 'No reason provided')
            logger.info(f"  ✗ {filename}")
            logger.info(f"    → {reason}")

    logger.info("\n" + "=" * 80)
    logger.info("VALIDATION")
    logger.info("=" * 80)

    # Validation
    files_moved = result.get('files_moved', [])
    files_skipped = result.get('files_skipped', [])

    expectations_met = True

    # Check 1: WebAgents-Oct30th.pdf should be skipped
    if "WebAgents-Oct30th.pdf" in files_moved:
        logger.error("❌ FAIL: WebAgents-Oct30th.pdf was moved (should be skipped!)")
        expectations_met = False
    elif "WebAgents-Oct30th.pdf" in files_skipped:
        logger.info("✅ PASS: WebAgents-Oct30th.pdf was correctly skipped")
    else:
        logger.warning("⚠ WARNING: WebAgents-Oct30th.pdf not found in results")

    # Check 2: Music files should be moved
    music_keywords = ['bad liar', 'hallelujah', 'let her go', 'mockingbird', 'perfect', 'night we met', 'until i found you']
    music_files_moved = [
        f for f in files_moved
        if any(keyword in f.lower() for keyword in music_keywords)
    ]

    if music_files_moved:
        logger.info(f"✅ PASS: Music files were moved: {len(music_files_moved)} files")
        for f in music_files_moved:
            logger.info(f"  - {f}")
    else:
        logger.warning("⚠ WARNING: No obvious music files were moved")
        expectations_met = False

    # Check 3: Target folder exists
    target_path = result.get('target_path')
    if target_path and os.path.exists(target_path):
        logger.info(f"✅ PASS: Target folder created at {target_path}")
        # List contents
        contents = os.listdir(target_path)
        logger.info(f"  Contents ({len(contents)} files):")
        for item in contents:
            logger.info(f"    - {item}")
    else:
        logger.error("❌ FAIL: Target folder not created")
        expectations_met = False

    logger.info("\n" + "=" * 80)

    if expectations_met:
        logger.info("✅✅✅ TEST PASSED - File organization worked as expected! ✅✅✅")
    else:
        logger.warning("⚠⚠⚠ TEST PARTIALLY PASSED - Some expectations not met ⚠⚠⚠")

    logger.info("=" * 80)


if __name__ == "__main__":
    test_file_organizer_direct()
