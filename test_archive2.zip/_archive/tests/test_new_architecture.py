#!/usr/bin/env python3
"""
Test the new separated Planner + Executor architecture.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import logging
import yaml
from src.orchestrator.planner import Planner
from src.orchestrator.executor import PlanExecutor
from src.orchestrator.tools_catalog import generate_tool_catalog, get_tool_specs_as_dicts

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def test_separated_architecture():
    """Test Planner and Executor separately."""

    logger.info("=" * 80)
    logger.info("Testing Separated Planner + Executor Architecture")
    logger.info("=" * 80)

    # Load config
    with open('config.yaml', 'r') as f:
        config = yaml.safe_load(f)

    # Initialize components
    tool_catalog = generate_tool_catalog()
    tool_specs = get_tool_specs_as_dicts(tool_catalog)

    planner = Planner(config)
    executor = PlanExecutor(config, enable_verification=False)  # Disable verification for now

    logger.info(f"\nInitialized with {len(tool_specs)} tools:")
    for tool in tool_specs:
        logger.info(f"  - {tool['name']}")

    # Test request
    user_request = "Organize all my music notes to a single folder called music stuff"

    logger.info(f"\n{'='*80}")
    logger.info("STEP 1: PLANNING")
    logger.info(f"{'='*80}")
    logger.info(f"Request: {user_request}\n")

    # Create plan
    plan_result = planner.create_plan(
        goal=user_request,
        available_tools=tool_specs
    )

    if not plan_result["success"]:
        logger.error(f"Planning failed: {plan_result['error']}")
        return

    plan = plan_result["plan"]
    logger.info(f"✅ Plan created with {len(plan)} steps:")
    logger.info(f"Reasoning: {plan_result['reasoning']}\n")

    for step in plan:
        logger.info(f"Step {step.get('id')}:")
        logger.info(f"  Action: {step.get('action')}")
        logger.info(f"  Parameters: {step.get('parameters')}")
        logger.info(f"  Reasoning: {step.get('reasoning')}")
        logger.info("")

    # Validate plan
    logger.info(f"{'='*80}")
    logger.info("STEP 2: VALIDATION")
    logger.info(f"{'='*80}\n")

    validation = planner.validate_plan(plan, tool_specs)

    if validation["valid"]:
        logger.info("✅ Plan is valid")
    else:
        logger.error(f"❌ Plan validation failed:")
        for issue in validation["issues"]:
            logger.error(f"  - {issue}")
        return

    if validation["warnings"]:
        logger.warning("Warnings:")
        for warning in validation["warnings"]:
            logger.warning(f"  - {warning}")

    # Execute plan
    logger.info(f"\n{'='*80}")
    logger.info("STEP 3: EXECUTION")
    logger.info(f"{'='*80}\n")

    exec_result = executor.execute_plan(
        plan=plan,
        goal=user_request
    )

    logger.info(f"\n{'='*80}")
    logger.info("EXECUTION RESULT")
    logger.info(f"{'='*80}")
    logger.info(f"Status: {exec_result['status'].value}")
    logger.info(f"Steps completed: {exec_result['steps_completed']}/{exec_result['steps_total']}")

    if exec_result.get("step_results"):
        logger.info("\nStep Results:")
        for step_id, step_result in exec_result["step_results"].items():
            logger.info(f"\n  Step {step_id}:")

            if step_result.get("error"):
                logger.error(f"    Error: {step_result.get('error_message')}")
            else:
                # Print key results
                for key in ["files_moved", "files_skipped", "target_path", "message"]:
                    if key in step_result:
                        value = step_result[key]
                        if isinstance(value, list):
                            logger.info(f"    {key}: {len(value)} items")
                            for item in value[:5]:  # Show first 5
                                logger.info(f"      - {item}")
                        else:
                            logger.info(f"    {key}: {value}")

    if exec_result["status"].value == "success":
        logger.info("\n✅✅✅ TEST PASSED ✅✅✅")
    else:
        logger.warning(f"\n⚠ Test completed with status: {exec_result['status'].value}")


if __name__ == "__main__":
    test_separated_architecture()
