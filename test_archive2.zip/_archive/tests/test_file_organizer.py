#!/usr/bin/env python3
"""
Test the file organizer feature with LLM-driven categorization.

Tests: "Organize all my music notes to a single folder called music stuff"
Expected: Move music-related PDFs but exclude WebAgents-Oct30th.pdf
"""

import logging
from src.orchestrator.main_orchestrator import MainOrchestrator
from src.utils import load_config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def test_file_organizer():
    """Test file organization with LLM-driven categorization."""

    logger.info("=" * 80)
    logger.info("Testing File Organizer")
    logger.info("=" * 80)

    # Load configuration
    config = load_config()

    # Create orchestrator
    orchestrator = MainOrchestrator(config)

    # Test command
    user_request = "Organize all my music notes to a single folder called music stuff"

    logger.info(f"\nUser Request: {user_request}")
    logger.info("\n" + "=" * 80)

    # Execute
    result = orchestrator.execute(user_request)

    logger.info("\n" + "=" * 80)
    logger.info("RESULT")
    logger.info("=" * 80)

    logger.info(f"Status: {result.get('status')}")

    # Print step results
    for step_id, step_result in result.get('step_results', {}).items():
        logger.info(f"\n{step_id}:")

        if step_result.get('error'):
            logger.error(f"  Error: {step_result.get('error_message')}")
        else:
            # Print relevant fields
            for key, value in step_result.items():
                if key in ['files_moved', 'files_skipped', 'target_path', 'message']:
                    logger.info(f"  {key}: {value}")

            # Print reasoning for each file
            if 'reasoning' in step_result:
                logger.info(f"\n  Reasoning:")
                for filename, reason in step_result['reasoning'].items():
                    logger.info(f"    - {filename}: {reason}")

    logger.info("\n" + "=" * 80)

    # Validation
    if result.get('status') == 'success':
        step_results = result.get('step_results', {})

        # Find organize_files step
        organize_step = None
        for step_result in step_results.values():
            if 'files_moved' in step_result:
                organize_step = step_result
                break

        if organize_step:
            files_moved = organize_step.get('files_moved', [])
            files_skipped = organize_step.get('files_skipped', [])

            logger.info("\nVALIDATION:")
            logger.info(f"Files moved: {len(files_moved)}")
            logger.info(f"Files skipped: {len(files_skipped)}")

            # Check expectations
            expectations_met = True

            # Should skip WebAgents-Oct30th.pdf
            if "WebAgents-Oct30th.pdf" in files_moved:
                logger.warning("❌ WebAgents-Oct30th.pdf was moved (should be skipped!)")
                expectations_met = False
            elif "WebAgents-Oct30th.pdf" in files_skipped:
                logger.info("✓ WebAgents-Oct30th.pdf was correctly skipped")

            # Should move music-related files like Bad Liar.pdf
            music_files_moved = [f for f in files_moved if any(
                word in f.lower() for word in ['bad', 'liar', 'song', 'music', 'lyrics']
            )]

            if music_files_moved:
                logger.info(f"✓ Music files moved: {music_files_moved}")
            else:
                logger.warning("⚠ No obvious music files were moved")

            if expectations_met:
                logger.info("\n✅ Test PASSED - File organization worked as expected!")
            else:
                logger.warning("\n⚠ Test PARTIALLY PASSED - Some expectations not met")
        else:
            logger.error("No organize_files step found in results")
    else:
        logger.error(f"Test FAILED - Status: {result.get('status')}")


if __name__ == "__main__":
    test_file_organizer()
